package carwash.main;

import java.util.Scanner;
import java.util.Vector;

import carwash.model.MPV;
import carwash.model.Motorcycle;
import carwash.model.Sedan;
import carwash.model.Truck;
import carwash.model.Vehicle;
import carwash.others.CarWashPackage;
import carwash.others.Customer;

class AddVehicle {

	Vector<Vehicle> vsList = null;

	public AddVehicle() {
		vsList = new Vector<Vehicle>();

	}

	public void addNewCustomer(Vehicle p) {
		vsList.add(p);
		p = null;
	}

	public void print() {

		System.out.println("");
		System.out.println(
				"============Vehicle in Wash List : ======================================================================================================");
		System.out.println(
				"Queue#.\tPlate No.\tOwner Name\tTelephone No.\t\tPackage Description\t\tPackage price\tTotal AddOn\tNet Total");
		System.out.println(
				"============================================================================================================================================");
		for (int i = 0; i < vsList.size(); i++) {

			System.out.printf(
					(i + 1) + ")\t" + vsList.get(i).getPlatNo() + "\t\t" + vsList.get(i).getCarOwnerDetails().getName()
							+ "\t\t" + vsList.get(i).getCarOwnerDetails().getTelNo() + "\t\t"
							+ vsList.get(i).getCarWashPackage().getDesc() + "\t\t"
							+ vsList.get(i).getCarWashPackage().getPrice() + "\t\t" + vsList.get(i).getTotalAddOn()
							+ "\t\t" + vsList.get(i).getTotalCharger());
			System.out.println("");
		}

	}

	public String returnPackageName(String packageNo) throws Exception {
		String packageName = "";

		switch (packageNo) {
		case "1":
			packageName = "Luar";
			break;
		case "2":
			packageName = "Dalam";
			break;
		case "3":
			packageName = "LuarDalam";
			break;
		case "4":
			packageName = "Motor";
			break;
		default:

			throw new Exception("No package selected.");
		}
		return packageName;
	}

}

public class TestCarWash {

	public static void main(String[] args) throws Exception {

		Scanner inp = new Scanner(System.in);
		AddVehicle avCust = new AddVehicle();
		Vehicle vehicle = null;

		Sedan sedan = null;
		Truck truck = null;
		MPV mpv = null;
		Motorcycle motor = null;
		try {

			int carType1 = 0;
			System.out.println("");
			System.out.println(
					"=============Hello, Welcome to Car Wash Billing System.==========================================================");

			System.out.println("Please enter vehicle type : ( [1].Sedan [2].Truck [3].MPV [4].Motorcycle [5].EXIT )");
			carType1 = Integer.parseInt(inp.next());

			while (carType1 != 5) {

				sedan = new Sedan(null, 0) {
				};
				truck = new Truck(0, 0) {
				};
				mpv = new MPV(null, 0) {
				};
				motor = new Motorcycle(null, 0) {
				};
				vehicle = new Vehicle() {
					public double calcTotalAddOn() throws Exception {
						return 0;
					}
				};

				switch (carType1) {
				case 1:
					System.out.println("Please enter car size ( [s]mall,[m]edium,[b]ig ) :");
					sedan.setCarSize(inp.next());
					break;
				case 2:
					System.out.println("Please enter no of wheel :");
					truck.setNoOfWheel(Integer.parseInt(inp.next()));
					break;
				case 3:
					System.out.println("Please enter MPV Type ( [m]pv / [s]uv ) :");
					mpv.setMPVType(inp.next());
					break;
				case 4:
					System.out.println("Is this 3 wheel motorcycle ? [y / n]");
					motor.setRodaTiga(inp.next());
					break;
				default:
					// System.out.println("No vehicle type selected.");
					throw new Exception("No vehicle type selected.");
				}
				// to catter motorcycle only
				if (carType1 != 4) {
					System.out.println(
							"Please enter the Package : ( [1].Luar Sahaja [2].Dalam Sahaja [3].Luar dan Dalam )");
					String packageName = inp.next();
					packageName = avCust.returnPackageName(packageName);
					CarWashPackage pack = Enum.valueOf(CarWashPackage.class, packageName);
					vehicle.setCarWashPackage(pack);
				} else {

					String packageName = "4";
					packageName = avCust.returnPackageName(packageName);
					CarWashPackage pack = Enum.valueOf(CarWashPackage.class, packageName);
					vehicle.setCarWashPackage(pack);
				}
				// adding new customer details and plate no.
				Customer customer = new Customer();

				System.out.println("Please enter Owner Name :");
				customer.setName(inp.next());

				System.out.println("Please enter Owner Contact no :");
				customer.setTelNo(inp.next());
				vehicle.setCarOwnerDetails(customer);

				System.out.println("Please enter Plate No of the vehicle :");
				vehicle.setPlatNo(inp.next());

				// calculate all total for the package including addon
				double totalCharger1 = vehicle.getCarWashPackage().getPrice();

				if (carType1 == 1) {
					double total1 = sedan.calcTotalAddOn();
					totalCharger1 = vehicle.getCarWashPackage().getPrice() + total1;
					sedan.setTotalSedanAddOn(total1);
					vehicle.setTotalAddOn(total1);
				}
				if (carType1 == 2) {
					double total1 = truck.calcTotalAddOn();
					totalCharger1 = vehicle.getCarWashPackage().getPrice() + total1;
					truck.setTotalTruckAddOn(total1);
					vehicle.setTotalAddOn(total1);
				}
				if (carType1 == 3) {
					double total1 = mpv.calcTotalAddOn();
					totalCharger1 = vehicle.getCarWashPackage().getPrice() + total1;
					mpv.setTotalMPVAddOn(total1);
					vehicle.setTotalAddOn(total1);
				}
				if (carType1 == 4) {
					double total1 = motor.calcTotalAddOn();
					totalCharger1 = vehicle.getCarWashPackage().getPrice() + total1;
					motor.setTotalMotorAddOn(total1);
					vehicle.setTotalAddOn(total1);
				}

				vehicle.setTotalCharger(totalCharger1);

				avCust.addNewCustomer(vehicle);
				avCust.print();
				vehicle = null;

				System.out.println("\n");
				System.out.println(
						"=============Hello, Welcome to Car Wash Billing System.==========================================================");
				System.out.println(
						"Adding more vehicle....Please enter vehicle type : ( [1].Sedan [2].Truck [3].MPV [4].Motorcycle [5].Exit )");
				carType1 = Integer.parseInt(inp.next());
			}

		} catch (Exception ex) {
			System.out.println("Exiting...There is an exception thrown : " + ex);

		} finally {
			inp.close();
			avCust = null;
			vehicle = null;

			sedan = null;
			truck = null;
			mpv = null;
			motor = null;
			System.out.println("Goodbye!!! Exiting the program....");
			System.exit(0);
		}

	}

}
