package carwash.interfaces;

public interface CarWashBillingInterfaces {

	public abstract double calcTotalAddOn() throws Exception;

}
