package carwash.others;

public enum CarWashPackage {

	Luar("Basuh luar sahaja.          ", 10.00), Dalam("Basuh dalam sahaja.         ",
			8.00), LuarDalam("Basuh luar dan dalam kenderaan.", 15.00), Motor("Motor sahaja.              ", 6.00);

	private String desc;
	private double price;

	// Constructor
	CarWashPackage(String d, double p) {
		desc = d;
		price = p;
	}

	public String getDesc() {
		return desc;
	}

	public double getPrice() {
		return price;
	}

}