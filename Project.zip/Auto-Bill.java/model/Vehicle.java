package carwash.model;

import carwash.others.CarWashPackage;
import carwash.others.Customer;

public abstract class Vehicle {

	protected int carType;
	protected String platNo;
	protected Customer carOwnerDetails;
	protected CarWashPackage carWashPackage;
	protected double totalCharger;
	protected double totalAddOn;

	public Vehicle() {

	}

	public Vehicle(int carType, String platNo, Customer carOwnerDetails, double totalCharger,
			CarWashPackage carWashPackage) {
		this.carType = carType;
		this.platNo = platNo;
		this.carOwnerDetails = carOwnerDetails;
		this.totalCharger = totalCharger;
		this.carWashPackage = carWashPackage;
	}

	public int getCarType() {
		return carType;
	}

	public void setCarType(int carType) {
		this.carType = carType;
	}

	public String getPlatNo() {
		return platNo;
	}

	public void setPlatNo(String platNo) {
		this.platNo = platNo;
	}

	public Customer getCarOwnerDetails() {
		return carOwnerDetails;
	}

	public void setCarOwnerDetails(Customer carOwnerDetails) {
		this.carOwnerDetails = carOwnerDetails;
	}

	public double getTotalCharger() {
		return totalCharger;
	}

	public void setTotalCharger(double totalCharger) {
		this.totalCharger = totalCharger;
	}

	public CarWashPackage getCarWashPackage() {
		return carWashPackage;
	}

	public void setCarWashPackage(CarWashPackage carWashPackage) {
		this.carWashPackage = carWashPackage;
	}

	public double getTotalAddOn() {
		return totalAddOn;
	}

	public void setTotalAddOn(double totalAddOn) {
		this.totalAddOn = totalAddOn;
	}

	public abstract double calcTotalAddOn() throws Exception;

}
