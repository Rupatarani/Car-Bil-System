package carwash.model;

import carwash.interfaces.CarWashBillingInterfaces;

public abstract class Sedan extends Vehicle implements CarWashBillingInterfaces {

	private String carSize;
	private double totalSedanAddOn;

	public Sedan(String carSize, double totalSedanAddOn) {
		super(0, null, null, 0, null);
		this.carSize = carSize;
		this.totalSedanAddOn = totalSedanAddOn;
	}

	public String getCarSize() {
		return carSize;
	}

	public void setCarSize(String carSize) {
		this.carSize = carSize;
	}

	public double getTotalSedanAddOn() {
		return totalSedanAddOn;
	}

	public void setTotalSedanAddOn(double totalSedanAddOn) {
		this.totalSedanAddOn = totalSedanAddOn;
	}

	public double calcTotalAddOn() throws Exception {
		double total = 0;

		switch (carSize) {
		case "s": // small
			total = total + 0;
			break;
		case "m": // medium
			total = total + 2;
			break;
		case "b": // Big
			total = total + 4;
			break;
		default:

			throw new Exception("No car size selected.");
		}

		return total;
	}
}
