package carwash.model;

import carwash.interfaces.CarWashBillingInterfaces;

public abstract class MPV extends Vehicle implements CarWashBillingInterfaces {

	private String MPVType;
	private double totalMPVAddOn;

	public MPV(String MPVType, double totalMPVAddOn) {
		super(0, null, null, 0, null);
		this.MPVType = MPVType;
		this.totalMPVAddOn = totalMPVAddOn;

	}

	public String getMPVType() {
		return MPVType;
	}

	public void setMPVType(String MPVType) {
		this.MPVType = MPVType;
	}

	public double getTotalMPVAddOn() {
		return totalMPVAddOn;
	}

	public void setTotalMPVAddOn(double totalMPVAddOn) {
		this.totalMPVAddOn = totalMPVAddOn;
	}

	public double calcTotalAddOn() throws Exception {
		double total = 0;

		switch (MPVType) {
		case "s":
			total = total + 3;
			break;
		case "m":
			total = total + 6;
			break;
		default:
			throw new Exception("No MPV type selected.");
		}

		return total;
	}
}
