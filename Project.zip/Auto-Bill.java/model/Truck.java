package carwash.model;

import carwash.interfaces.CarWashBillingInterfaces;

public abstract class Truck extends Vehicle implements CarWashBillingInterfaces {

	private int noOfWheel;
	private double totalTruckAddOn;

	public Truck(int noOfWheel, double totalTruckAddOn) {
		super(0, null, null, 0, null);
		this.noOfWheel = noOfWheel;
		this.totalTruckAddOn = totalTruckAddOn;
	}

	public int getNoOfWheel() {
		return noOfWheel;
	}

	public void setNoOfWheel(int noOfWheel) {
		this.noOfWheel = noOfWheel;
	}

	public double getTotalTruckAddOn() {
		return totalTruckAddOn;
	}

	public void setTotalTruckAddOn(double totalTruckAddOn) {
		this.totalTruckAddOn = totalTruckAddOn;
	}

	public double calcTotalAddOn() throws Exception {

		double total = 0;

		if (noOfWheel == 1 || noOfWheel == 2) {
			total = total + 2;

		} else if (noOfWheel == 3 || noOfWheel == 4) {
			total = total + 4;

		} else if (noOfWheel > 4) {
			total = total + 10;

		} else {
			total = total + 0;
			throw new Exception("Incorrect input of No Of Wheel.");
		}

		return total;
	}
}
