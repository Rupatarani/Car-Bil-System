package carwash.model;

import carwash.interfaces.CarWashBillingInterfaces;

public abstract class Motorcycle extends Vehicle implements CarWashBillingInterfaces {

	private String rodaTiga;
	private double totalMotorAddOn;

	public Motorcycle(String rodaTiga, double totalMotorAddOn) {
		super(0, null, null, 0, null);
		this.rodaTiga = rodaTiga;
		this.totalMotorAddOn = totalMotorAddOn;
	}

	public String getRodaTiga() {
		return rodaTiga;
	}

	public void setRodaTiga(String rodaTiga) {
		this.rodaTiga = rodaTiga;
	}

	public double getTotalMotorAddOn() {
		return totalMotorAddOn;
	}

	public void setTotalMotorAddOn(double totalMotorAddOn) {
		this.totalMotorAddOn = totalMotorAddOn;
	}

	public double calcTotalAddOn() throws Exception {
		double total = 0;

		switch (rodaTiga) {
		case "y":
			total = total + 2;
			break;
		case "n":
			total = total + 0;
			break;
		default:
			throw new Exception("Invalid 3 wheel motorcycle input.");
		}

		return total;
	}
}
